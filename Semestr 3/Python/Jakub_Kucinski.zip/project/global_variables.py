"""Moduł zawiera zmienne globalne całej aplikacji."""

USER_ID = None
MAX_RANK = 5.0
MIN_RANK = 0.5
host = "localhost"
user = "root"
passwd = "011235"
database = "recommendation_system"
use_pure = True
